function setup() {
  createCanvas(500, 500);
  
  
}

function draw() {
  background(220);
  
  
  
  for(let i =1; i < 10; i++){
  
  let s = i*.33;
  let r = i*.3;
    
 
  translate(i*10,i);
  
  
    
    
  
  cloud(s,r,i);
  
}
  
  
  
}


function cloud(s,r,i){
  fill(255);
  angleMode(DEGREES)
  
  push();
  strokeWeight(0);
  scale(s);
  rotate(r);
  
  if(i%2 ==0){
    pop();
  }
  
  
  
  
  
  circle(0,50,50);
  circle(30,50,50);
  circle(60,50,50);
  circle(15,25,50);
  circle(45,25,50);
  
}

