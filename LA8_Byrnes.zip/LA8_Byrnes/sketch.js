function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(220);
  
  
  image(img1, mouseX, mouseY);
  //image(imgT, 100,100+mouseX);
  
  
  
  textFont('Helvetica');
  strokeWeight(4);
  fill(110);
  
  text('I cannot get a transparent image because adobe sucks, so have this glass.', 10, 70);
  
  
  
  
  
  
}


function preload(){
  img1 = loadImage("glass.jpg");
  //imgt = loadImage();
  
  
}