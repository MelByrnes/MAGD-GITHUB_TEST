let weirdSphere

function setup() {
  createCanvas(400, 400, WEBGL)

 
  
  weirdSphere = csg(() => sphere(40))
    .subtract(() => {
      translate(40, 40)
      sphere(65)
    })
    .union(() => sphere(70))
   .intersect(() => {
      translate(-40, 40)
      sphere(65)
    })
  .union(() => sphere(40))
  
  
    .done()
}

function draw() {
  clear()
  orbitControl()
  noStroke()
  lights()
  model(weirdSphere)
}